from tkinter import *
from PIL import *

class ShootingGame:
    def __init__(self):
        self.window = Tk()#위도우 생성
        self.window.title("슈팅게임")#윈도우 이름
        self.window.geometry("768x1366")#윈도우 크기 설정
        self.canvas=Canvas(self.window, bg ="gray")#그림판 생성
        self.canvas.pack(expand=True, fill=BOTH)#그림판을 윈도우에 붙이기
        self.keys = set()
        self.window.bind("<KeyPress>",self.keyPressHandler)
        self.window.bind("<KeyRelease>",self.keyReleaseHandler)
        self.window.protocol("WM_DELETE_WINDOW", self.onClose)
        self.start_img = PhotoImage(file="start_btn.png").subsample(2,2)
        self.name_img = PhotoImage(file="name_banner.png").zoom(2,2)
        self.draw_start_screen()

        #게임 Main 루프
        while True:
            try:
                pass

            except TclError:
                return

            self.window.after(33)#33ms 대기
            self.window.update()#화면 업데이트

    def draw_start_screen(self):
        self.canvas.create_image(683, 200, image=self.name_img, tags="start_menu")
        self.canvas.create_image(683, 500, image=self.start_img, tags="start_button")
        self.canvas.tag_bind("start_button", "<Button-1>", self.start_game)
        self.canvas.tag_bind("start_button", "<Enter>", lambda e: self.canvas.config(cursor="hand2"))
        self.canvas.tag_bind("start_button", "<Leave>", lambda e: self.canvas.config(cursor=""))

    #키 눌림 
    def keyPressHandler(self,event):        
        if event.keycode == 27:#esc key 입력시 종료	
            print("ESC가 입력됨")
            self.onClose()
        else:
            self.keys.add(event.keycode)# keys(set타입 변수) 에 입력된 keycode를 추가한다.

    #키 해제
    def keyReleaseHandler(self, event):
        if event.keycode in self.keys:#키를 해제했을 때 keys에 해제한 키가 있는지 체크
            self.keys.remove(event.keycode) #만약 있으면 keys 안에 값 제거

    def onClose(self):        
        self.window.destroy()

    def start_game(self, event):
        print("게임 시작!")
        self.canvas.delete("start_button")
        self.canvas.delete("start_menu")

if __name__=='__main__':
    ShootingGame()